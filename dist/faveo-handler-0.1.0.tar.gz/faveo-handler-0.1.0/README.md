# Faveo Handler

A Python library to interact with the Faveo API