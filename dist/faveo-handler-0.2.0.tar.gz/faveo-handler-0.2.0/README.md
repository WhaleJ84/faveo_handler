# Faveo Handler

A Python library to interact with the Faveo API

## Installation

This repository is designed to be used as a Pip module. You can pull it by running the following:

```shell script
# Pip
python3 -m pip install git+https://github.com/WhaleJ84/faveo_handler.git

# Pipenv
python3 -m pipenv install -e git+https://github.com/WhaleJ84/faveo_handler.git#egg=faveo_handler
```
