# https://github.com/ladybirdweb/faveo-helpdesk/wiki/Reply-Ticket
# https://github.com/ladybirdweb/faveo-helpdesk/wiki/Edit-Ticket
# https://github.com/ladybirdweb/faveo-helpdesk/wiki/Create-Internal-Note
# https://github.com/ladybirdweb/faveo-helpdesk/wiki/Collaborator-Create
# https://github.com/ladybirdweb/faveo-helpdesk/wiki/Collaborator-Remove
class Update:
    def __init__(self):
        pass
